import tkinter
from 发送邮件.smtp import Mail

class Client:
    def __init__(self):
        self.win = tkinter.Tk()
        self.win.title("邮件发送客户端")
        self.win.geometry("600x500+0+0")

        self.label1 = tkinter.Label(self.win,text = "用户名:")
        self.entry1 = tkinter.Entry(self.win)
        self.label1.place(x = 10,y = 10)
        self.entry1.place(x = 50,y = 10)

        self.label2 = tkinter.Label(self.win,text = "密码：")
        self.entry2 = tkinter.Entry(self.win,show= '*')
        self.label2.place(x = 10,y = 50)
        self.entry2.place(x = 50,y = 50)

        self.label5 = tkinter.Label(self.win,text = "主题：")
        self.entry4 = tkinter.Entry(self.win)
        self.label5.place(x = 190,y = 50)
        self.entry4.place(x = 230,y = 50)

        self.label3 = tkinter.Label(self.win,text = "邮件内容：")
        # self.var1 = tkinter.StringVar()
        self.text1 = tkinter.Text(self.win)

        self.text1.place(x = 10,y = 80)

        self.label4 = tkinter.Label(self.win,text = "收件人：")
        self.entry3 = tkinter.Entry(self.win)
        self.label4.place(x = 10,y = 400)
        self.entry3.place(x = 60,y = 400)

        self.button = tkinter.Button(self.win,text = "发送",command = self.connect)
        self.button.place(x = 220,y = 400)
    def connect(self):
        sender = self.entry1.get()
        password = self.entry2.get()
        content = self.text1.get('0.0','end')
        title = self.entry4.get()
        senderlist = self.entry3.get()
        print(sender,password,content,title,senderlist)
        S = Mail('smtp.163.com',sender,password,content,title,senderlist)
        S.sendMail()
        S.quit()
    def show(self):
        self.win.mainloop()
a = Client()
a.show()