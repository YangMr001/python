import smtplib  #发送邮件的
from email.mime.text import MIMEText #邮件的文本
# from 发送邮件.图形化邮箱 import Client

class Mail:
    def __init__(self,smtp,sender,password,content,title,senderlist):
        self.SMTPServer = smtp #SMTP服务器
        self.sender = sender #用户名
        self.password = password#密码
        self.content = content
        self.title = title
        self.senderlist = senderlist
    def sendMail(self):
        message = self.content #发送的信息
        mes = MIMEText(message) #转换成邮件的格式
        mes["Subject"] = self.title #标题
        mes['From'] = self.sender #发送者
        mes['to']  = self.senderlist
        self.mailServer = smtplib.SMTP(self.SMTPServer,25) #绑定端口号
        self.mailServer.login(self.sender,self.password) #登陆
        self.mailServer.sendmail(self.sender,self.senderlist,mes.as_string()) #发送邮件
    def quit(self):
        self.mailServer.quit() #退出

# mail = Mail('smtp.163.com',"YPS_Mr@163.com","ps123456","ssss","aaa","252943669@qq.com")
# mail.sendMail()
# mail.quit()